#ifndef CLASSES_H
#define CLASSES_H

class Color{    
    private:
     int m_Red, m_Green, m_Blue =0;

    public:
        Color(int red, int green, int blue):m_Red(red), m_Green(green), m_Blue(blue){};
        Color add(Color a){
            return Color(a.m_Red+m_Red, a.m_Green+m_Green,a.m_Blue+m_Blue);
        }
};
#endif // CLASSES_H